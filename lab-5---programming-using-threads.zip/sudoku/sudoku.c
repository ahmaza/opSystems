#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define SIZE 9
#define B_SIZE 3
// Sudoku board. Modify this to test your checker!
// 0 == empty cell; 1-9 is the filled in digit.
int board[SIZE][SIZE] = {
    {1,3,4,5,6,2,9,7,3},
    {5,2,6,1,4,8,9,4,7},
    {7,9,3,6,8,2,4,6,0},
    {6,5,3,4,2,1,7,8,0},
    {6,4,3,2,5,6,8,9,0},
    {3,2,4,3,5,6,8,1,9},
    {2,4,6,8,1,0,7,3,4},
    {6,4,2,7,5,1,5,8,0},
    {7,8,1,3,5,7,2,6,9},
};

bool r_check[SIZE];
bool c_check[SIZE];
bool b_check[SIZE];

void printBoard(int board[SIZE][SIZE]) {
    for(int i = 0; i<SIZE; i++) {
        for(int j = 0; j<SIZE; j++) {
            printf("%5d", board[i][j]);
        }
        printf("\n");
    }
    printf("\n");
}

// Checks the given row for duplicate numbers, and updates the row_check
// value for that row appropriately. If no number is repeated in that row,
// row_check[row] will be set to true; otherwise, it will be false.
void* checkRow(void* args) {
  int rtemp_check[SIZE];
  for(int x = 0; x < SIZE; x++) {
    r_check[x] = true; 
    for (int y = 0; y < SIZE; y++) {
      rtemp_check[y] = board[x][y];
      for(int z = 0; z < y; z++) 
      {
        r_check[x] = false;
        break;
      }
    }
    if (!r_check[x]) { 
      break; 
    }
    
  }
}


// Checks the given col for duplicate numbers, and updates the col_check
// value for that col appropriately. If no number is repeated in that col,
// col_check[col] will be set to true; otherwise, it will be false.
void* checkCol(void* args) {
    int ctemp_check[SIZE];
    for (int x = 0; x < SIZE; x++) {
      c_check[x] = true;
      for(int y = 0; y < SIZE; y++) {
        ctemp_check[y] = board[x][y];
        for(int z = 0; z < y; z++) {
          if (ctemp_check[z] == board[x][y]) {
            c_check[x] = false;
            break;
          }
        }
        if (!c_check[x]) { 
          break;
        }
      }
    }
}

// Checks the given 3x3 box for duplicate numbers, and updates the box_check
// value for that box appropriately. If no number is repeated in that box,
// box_check[box] will be set to true; otherwise, it will be false.
void* checkBox(void* args) {
  // intialize
  int btemp_check[SIZE];
  int btemp_check_i;
  btemp_check_i = 0; 
  
  int r_indexST;
  r_indexST = 0;
  
  int c_indexST;
  c_indexST = 0;
  
  int r_indexEN;
  r_indexEN = 2;
  
  int c_indexEN;
  c_indexEN = 2;
  
  for(int x = 0; x < SIZE; x++) 
  {
    b_check[x] = true;
    //for loops
    for (int y = r_indexST; y <= r_indexEN; y++)
    {
      for(int z = c_indexST; z <= c_indexEN; z++, btemp_check_i)
      {
        btemp_check[btemp_check_i] = board[y][z];
        for (int a = 0; a < btemp_check_i; a++) 
        {
          if (btemp_check[a] == board[y][z]) 
          {
            b_check[x] = false;
            break;
          }
        }
        if(!b_check[x]) 
        {
          break; 
        }
      }
      if (!b_check[x]) 
      {
        break;  
      }
     if (c_indexEN < SIZE - 1)
     {
       c_indexST = c_indexST + B_SIZE;
       c_indexEN = c_indexEN + B_SIZE;
     }
     else if (r_indexEN < SIZE - 1) 
     {
       r_indexST = r_indexST + B_SIZE;
       r_indexEN = r_indexEN + B_SIZE;
     }
      for (int x = 0; x < SIZE; x++)
      {
        btemp_check[x] = 0;
      }
    }  
  } 
}

// Spawn a thread to fill each cell in each result matrix.
// How many threads will you spawn?
int main() { 
    // 1. Print the board.
    printf("Board:\n");
    printBoard(board);
    
    // 2. Create pthread_t objects for our threads.
    pthread_t parallel_r;
    pthread_t parallel_c;
    pthread_t parallel_b;
  
    void* parallel_rEX; 
    void* parallel_cEX;
    void* parallel_bEX;
    // 3. Create a thread for each cell of each matrix operation.
    
    if (pthread_create(&parallel_r, NULL, &checkRow, NULL) != 0) 
    {
      perror(" A parallel creation error has occured.");
      if (pthread_cancel(parallel_r) != 0) 
      {
        perror(" A parallel creation error has occured.");
      }
    }
  
    if (pthread_create(&parallel_c, NULL, &checkCol, NULL) != 0) 
    {
      perror("A parallel creation error has occured.");
      if (pthread_cancel(parallel_c) != 0) 
      {
        perror("A parallel creation error has occured.");
      }
    }
  
    if (pthread_create(&parallel_b, NULL, &checkBox, NULL) != 0) 
    {
      perror("A parallel creation error has occured.");
      if (pthread_cancel(parallel_b) != 0) 
      {
        perror("A parallel creation error has occured.");
      }
    } 
    // 4. Wait for all threads to finish.
    
    if (pthread_join(parallel_r, &parallel_rEX) != 0)
    {
      perror("A parallel termination error has occurred.");
    }
    
    if (pthread_join(parallel_b, &parallel_bEX) != 0)
    {
      perror("A parallel termination error has occurred.");
    }
  
    
    
    // 5. Print the results.
    printf("Results:\n");
    bool all_rows_passed = true;
    printf("Rows:\n");
    for (int i = 0; i < SIZE; i++) {
        if (!r_check[i]) {
            printf("Row %i did not pass\n", i);
            all_rows_passed = false;
        }
    }
    if (all_rows_passed) {
        printf("All rows passed!\n");
    }
    
    bool all_cols_passed = true;
    printf("Cols:\n");
    for (int i = 0; i < SIZE; i++) {
        if (!c_check[i]) {
            printf("Col %i did not pass\n", i);
            all_cols_passed = false;
        }
    }
    if (all_cols_passed) {
        printf("All cols passed!\n");
    }
    
    bool all_boxes_passed = true;
    printf("Boxes:\n");
    for (int i = 0; i < SIZE; i++) {
        if (!b_check[i]) {
            printf("Box %i did not pass\n", i);
            all_boxes_passed = false;
        }
    }
    if (all_boxes_passed) {
        printf("All boxes passed!\n");
    }
    return 0;
}


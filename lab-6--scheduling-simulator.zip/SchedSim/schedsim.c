// C program for implementation of Simulation 
#include<stdio.h> 
#include<limits.h>
#include<stdlib.h>
#include "process.h"
#include "util.h"
//change to id
int to_id(const void *this, const void *that) 
{
  ProcessType *processOne = (ProcessType *) this;
  ProcessType *processTwo = (ProcessType *) that;
  
  int processOneID = processOne->pid;
  int processTwoID = processTwo->pid;
  
  if (processOneID < processTwoID) 
  {
   return 0; 
  }
  return 1;
}
//change to burst time
int to_bt(const void *this, const void *that) 
{
  ProcessType *processOne = (ProcessType *) this;
  ProcessType *processTwo = (ProcessType *) that;
  
  int processOneBt = processOne->pid;
  int processTwoBt = processTwo->pid;
  
  if (processOneBt < processTwoBt) 
  {
    return 0;
  }
  return 1;
}




// Function to find the waiting time for all  
// processes
void findWaitingTimeRR(ProcessType plist[], int n,int quantum) 
{ 
  
  
    // 1. Create an array *rem_bt[]* to keep track of remaining burst time of processes. This array is initially a copy of *plist[].bt* (all processes burst times)
    int rem_bt[n];
    // 2. Store waiting times of processes in plist[].wt. Initialize this array as 0.
    int rem_wt[n];
  
    for (int x = 0; x < n; x++) 
    {
      rem_bt[x] = plist[x].bt;
      rem_wt[x] = 0;
    }
  //   3. Initialize time : t = 0
    int time = 0;
    
   //  4. Keep traversing the all processes while all processes are not done. Do following for i'th process if it is not done yet.
    for (int a = 0; a < n; a++) 
    {
      if (rem_bt[a] > quantum) 
      {
        time += quantum;
        rem_bt[a] -= quantum;
      }
      else 
      {
        time += rem_bt[a];
        
        if (!rem_wt[a]) 
        {
          rem_wt[a] = time - plist[a].bt;
          plist[a].wt = rem_wt[a];
        }
        rem_bt[a] = 0;
      }
      
      int finished = 1;
      if (a == n - 1) 
      {
        for (int b = 0; b < n; b++) 
        {
          if (rem_bt[b] > 0) 
          {
            finished = 0;
          }
        }
        if (!finished) 
        {
          a = -1;
        }
      }
    }
        
} 

// Function to find the waiting time for all  
// processes 
void findWaitingTimeSJF(ProcessType plist[], int n)
{ 
      int index = -1;
      int const_bt = -1;
      int dynamic_bt = -1;
      int curr_time = 0;
      int comp_time = 0;
      int completed_proc = 0;
    
      Comparer process_comparerBT = &to_bt;
  
      qsort(plist, n, sizeof(ProcessType), process_comparerBT);
  
      for (int lap = 0; completed_proc < n; lap++) 
      {
        const_bt = plist[lap].bt;
        dynamic_bt = const_bt;
        
        for (int x = 0; x < const_bt; x++, curr_time) 
        {
          index = lap;
          
          if (dynamic_bt > 0) 
          {
            dynamic_bt -= 1;
          }
          if (dynamic_bt == 0) 
          {
            completed_proc += 1;
            comp_time = curr_time + 1;
            
            plist[index].wt = comp_time - plist[index].art - plist[index].bt;
                        
          }  
        }  
      }  
} 

// Function to find the waiting time for all  
// processes 
void findWaitingTime(ProcessType plist[], int n)
{ 
    // waiting time for first process is 0, or the arrival time if not 
    plist[0].wt = 0 +  plist[0].art; 
  
    // calculating waiting time 
    for (int  i = 1; i < n ; i++ ) 
        plist[i].wt =  plist[i-1].bt + plist[i-1].wt; 
} 
  
// Function to calculate turn around time 
void findTurnAroundTime( ProcessType plist[], int n)
{ 
    // calculating turnaround time by adding bt[i] + wt[i] 
    for (int  i = 0; i < n ; i++) 
        plist[i].tat = plist[i].bt + plist[i].wt; 
} 
  
// Function to sort the Process acc. to priority
int my_comparer(const void *this, const void *that)
{ 
    
    ProcessType *processOne = (ProcessType *) this;
    ProcessType *processTwo = (ProcessType *) that;
  
    int processOnePri = processOne->pri;
    int processTwoPri = processTwo->pri;
  
    if (processOnePri < processTwoPri) 
    {
      return 1;
    }
    return 0;
} 

//Function to calculate average time 
void findavgTimeFCFS( ProcessType plist[], int n) 
{ 
    //Function to find waiting time of all processes 
    findWaitingTime(plist, n); 
  
    //Function to find turn around time for all processes 
    findTurnAroundTime(plist, n); 
  
    //Display processes along with all details 
    printf("\n*********\nFCFS\n");
}

//Function to calculate average time 
void findavgTimeSJF( ProcessType plist[], int n) 
{ 
    //Function to find waiting time of all processes 
    findWaitingTimeSJF(plist, n); 
  
    //Function to find turn around time for all processes 
    findTurnAroundTime(plist, n); 
  
    Comparer process_comparerID = &to_id; 
  
    qsort(plist, n, sizeof(ProcessType), process_comparerID);
  
    //Display processes along with all details 
    printf("\n*********\nSJF\n");
}

//Function to calculate average time 
void findavgTimeRR( ProcessType plist[], int n, int quantum) 
{ 
    //Function to find waiting time of all processes 
    findWaitingTimeRR(plist, n, quantum); 
  
    //Function to find turn around time for all processes 
    findTurnAroundTime(plist, n); 
  
    //Display processes along with all details 
    printf("\n*********\nRR Quantum = %d\n", quantum);
}

//Function to calculate average time 
void findavgTimePriority( ProcessType plist[], int n) 
{ 
    Comparer process_comparer = &my_comparer;
   /*
    * 1- 
    * Sort the processes (i.e. plist[]), burst time and priority according to the priority.
    * 2- Now simply apply FCFS algorithm.
    */
    qsort(plist, n, sizeof(ProcessType), process_comparer);
  
    findWaitingTime(plist, n);
    findTurnAroundTime(plist,n);
  
    //Display processes along with all details 
    printf("\n*********\nPriority\n");
}

void printMetrics(ProcessType plist[], int n)
{
    int total_wt = 0, total_tat = 0; 
    float awt, att;
    
    printf("\tProcesses\tBurst time\tWaiting time\tTurn around time\n"); 
  
    // Calculate total waiting time and total turn  
    // around time 
    for (int  i=0; i<n; i++) 
    { 
        total_wt = total_wt + plist[i].wt; 
        total_tat = total_tat + plist[i].tat; 
        printf("\t%d\t\t%d\t\t%d\t\t%d\n", plist[i].pid, plist[i].bt, plist[i].wt, plist[i].tat); 
    } 
  
    awt = ((float)total_wt / (float)n);
    att = ((float)total_tat / (float)n);
    
    printf("\nAverage waiting time = %.2f", awt); 
    printf("\nAverage turn around time = %.2f\n", att); 
} 

ProcessType * initProc(char *filename, int *n) 
{
  	FILE *input_file = fopen(filename, "r");
	  if (!input_file) {
		    fprintf(stderr, "Error: Invalid filepath\n");
		    fflush(stdout);
		    exit(0);
	  }

    ProcessType *plist = parse_file(input_file, n);
  
    fclose(input_file);
  
    return plist;
}
  
// Driver code 
int main(int argc, char *argv[]) 
{ 
    int n; 
    int quantum = 2;

    ProcessType *proc_list;
  
    if (argc < 2) {
		   fprintf(stderr, "Usage: ./schedsim <input-file-path>\n");
		   fflush(stdout);
		   return 1;
	   }
    
  // FCFS
    n = 0;
    proc_list = initProc(argv[1], &n);
  
    findavgTimeFCFS(proc_list, n);
    
    printMetrics(proc_list, n);
  
  // SJF
    n = 0;
    proc_list = initProc(argv[1], &n);
   
    findavgTimeSJF(proc_list, n); 
   
    printMetrics(proc_list, n);
  
  // Priority
    n = 0; 
    proc_list = initProc(argv[1], &n);
    
    findavgTimePriority(proc_list, n); 
    
    printMetrics(proc_list, n);
    
  // RR
    n = 0;
    proc_list = initProc(argv[1], &n);
    
    findavgTimeRR(proc_list, n, quantum); 
    
    printMetrics(proc_list, n);
    
    return 0; 
} 
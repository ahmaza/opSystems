#ifndef UTIL_H
#define UTIL_H

/**
 * Utility function file
 */


void parse_file(FILE *, int [][2], int *, int *);

#endif				// UTIL_H